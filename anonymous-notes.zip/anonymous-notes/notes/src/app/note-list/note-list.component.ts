import { Component, OnInit, Input } from '@angular/core';
import { HttpService } from './../http.service';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';


@Component({
  selector: 'app-note-list',
  templateUrl: './note-list.component.html',
  styleUrls: ['./note-list.component.css']
})
export class NoteListComponent implements OnInit {
  @Input() notesarray;
  constructor(private _communicateService: HttpService) { }

  ngOnInit() {
    
      this._communicateService.retrieveAll()
      .then( (all) =>{ this.notesarray = all })
      .catch( (err) => { console.log(err); })
  }

}
