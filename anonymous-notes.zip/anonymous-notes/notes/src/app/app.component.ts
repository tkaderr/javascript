import { Component } from '@angular/core';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { HttpService } from './http.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  notes=[];

  newnote = new Note();

  constructor(private _communicateService: HttpService) {
	
  	}

  onSubmit(form){
      this._communicateService.create(this.newnote)
      .then( (all) =>{ console.log("success", all); })
      .catch( (err) => { console.log(err); })

      this._communicateService.retrieveAll()
      .then( (all) =>{ this.notes = all })
      .catch( (err) => { console.log(err); })

     
    if (form.submitted){
      this.newnote = new Note();
      form.resetForm();
    }
  }

}

export class Note {
  constructor(
     public note:string = ""
     ){
    
  }
}
